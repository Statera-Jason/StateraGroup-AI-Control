# Summary

## Linked issue
Closes #

## What changed

## How to verify

## Risks / rollbacks

## Checklist
- [ ] Scope matches issue
- [ ] Tests/verifications executed
- [ ] Docs updated (if needed)
