# Governance (Project420 Prototype)

This repository follows PAC-style execution with a **Phase Anchor** issue as the trunk of work.

## Roles
- **Human (You)**: defines intent, approves scope, creates/curates Phase Anchors and child issues.
- **Copilot**: assists with **manual** creation of the Phase Anchor + decomposed child issues using the repo prompts/templates.
- **Executors (IDE Agents)**: implement scoped work from issues:
  - Claude Code
  - Codex

## Non-negotiables
- No work without an issue.
- Every change must map to a single issue (or a child issue under the Phase Anchor).
- Scope is defined by the issue; anything outside scope requires a new issue or an explicit scope update.
- Prefer small PRs aligned to one issue.

## Issue types
- **Phase Anchor**: the parent/trunk issue for a phase.
- **Task**: a decomposed child issue with a clear DoD.

See: `EXECUTION.md` and `.statera/pac/ISSUE_SPEC.md`.
