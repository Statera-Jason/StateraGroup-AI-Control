# Branch Specification

## Pattern
- `ai/<issue-id>-<short-slug>`

Examples:
- `ai/123-add-phase-anchor-template`
- `ai/456-fix-webhook-validation`

## Rules
- One branch per issue.
- No mixing multiple issues into one branch.
- Keep branches short-lived; merge via PR.
