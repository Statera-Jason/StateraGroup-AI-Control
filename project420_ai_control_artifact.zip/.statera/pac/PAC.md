# PAC (Project420 Prototype)

## Principle
Policy-first execution: scope is explicit, work is attributable, and governance is fail-closed.

## Workflow
1. Create a **Phase Anchor** issue with:
   - Goal
   - Non-goals
   - Acceptance criteria
   - Constraints (allowed paths/tools)
   - Child issue checklist (links)
2. Decompose into **Task** child issues.
3. Executors pick up `status:ready` tasks, implement, and open PRs.
4. Close tasks; close Phase Anchor when all children are done and AC is met.

## Guardrails
- No direct "drive-by" commits to main.
- No secret material committed.
- No widening scope without recording it in GitHub.
