# Label Taxonomy

## Phase / Scope
- `phase:anchor` — Phase parent issue
- `scope:approved` — scope approved to execute
- `scope:blocked` — not approved, do not execute

## Executor routing
- `executor:claude`
- `executor:codex`

## Type
- `type:task`
- `type:bug`

## Status
- `status:ready`
- `status:in-progress`
- `status:done`

## Priority (optional)
- `priority:p0`
- `priority:p1`
- `priority:p2`
