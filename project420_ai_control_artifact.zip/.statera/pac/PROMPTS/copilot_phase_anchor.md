You are GitHub Copilot. Create a **Phase Anchor** issue in this repository.

STRICT RULES:
- Follow the Phase Anchor schema from `.statera/pac/ISSUE_SPEC.md`.
- Use the issue template format: Goal, Non-goals, Acceptance Criteria, Constraints, Child Issues.
- Apply labels: `phase:anchor` and `scope:blocked`.
- Write crisp, unambiguous criteria. No vague statements.

INPUTS (fill from my message):
- Phase name:
- Goal:
- Non-goals:
- Acceptance criteria:
- Constraints:
- Initial child issue list (titles only):

OUTPUT:
- A complete Phase Anchor issue body ready to paste into GitHub.
