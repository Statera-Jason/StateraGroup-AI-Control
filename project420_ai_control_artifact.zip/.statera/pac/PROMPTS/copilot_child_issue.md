You are GitHub Copilot. Create N **Task** child issues under an existing Phase Anchor.

STRICT RULES:
- Each child issue must follow `.statera/pac/ISSUE_SPEC.md` (Task schema).
- Each must include: Problem Statement, Constraints, DoD, Paths, Verification Steps.
- Apply labels: `type:task`, `status:ready`, and exactly one of: `executor:claude` or `executor:codex`.
- Each task must be independently mergeable.

INPUTS:
- Phase Anchor link:
- N:
- High-level decomposition bullets:
- Preferred executor for each bullet (claude/codex):

OUTPUT:
- N complete issue bodies ready to paste, each separated clearly.
