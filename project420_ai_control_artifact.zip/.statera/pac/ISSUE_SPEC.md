# Issue Specification

## Phase Anchor (parent/trunk)
Required sections:
- **Goal**
- **Non-goals**
- **Acceptance Criteria** (binary, testable)
- **Constraints**
  - allowed paths
  - tooling constraints
  - dependencies
- **Child Issues** (checkbox list linking to child issues)

Required labels:
- `phase:anchor`
- `scope:approved` (or `scope:blocked` until approved)

## Task (child issue)
Required sections:
- **Problem Statement**
- **Constraints**
- **Definition of Done**
- **Files/Paths Expected to Change**
- **Verification Steps**

Required labels:
- `type:task`
- `status:ready`
- exactly one of: `executor:claude` | `executor:codex`
