# Execution Rules (Executors: Claude Code + Codex)

## 1) Always start from an issue
- Read the issue body and all linked constraints.
- Confirm:
  - Allowed paths / repos
  - Definition of Done (DoD)
  - Verification steps

## 2) Fail-closed scope
If anything is unclear or out of scope:
- Do not guess.
- Propose a minimal question or propose a new child issue.

## 3) Branching
- Create one branch per issue:
  - `ai/<issue-id>-<short-slug>`
- Keep commits tight and descriptive.

## 4) PR requirements
- PR title references the issue: `#<id> <title>`
- PR body includes:
  - What changed
  - How to verify
  - Risks / rollbacks
  - Checklist completion

## 5) Labels
Child issues must include:
- `status:ready`
- one executor label: `executor:claude` or `executor:codex`

## 6) Codex project trust
Codex only loads `.codex/config.toml` for **trusted** projects. Ensure the Executor machine trusts this repo before running.
